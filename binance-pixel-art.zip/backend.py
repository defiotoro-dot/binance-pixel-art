#!/usr/bin/env python3
"""
幣安本地後端 - 查詢個人數據
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import hmac
import hashlib
import time
import requests
import os

app = Flask(__name__)
CORS(app)

BINANCE_API = "https://api.binance.com"

# 從環境變數讀取 API Key（如果有的話）
DEFAULT_API_KEY = os.environ.get('BINANCE_API_KEY', '')
DEFAULT_API_SECRET = os.environ.get('BINANCE_API_SECRET', '')

def sign(query_string, secret):
    return hmac.new(
        secret.encode('utf-8'),
        query_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()

@app.route('/api/account', methods=['GET'])
def get_account():
    # 優先使用 headers 裡的 key，否則用環境變數
    api_key = request.headers.get('X-API-KEY', DEFAULT_API_KEY)
    api_secret = request.headers.get('X-API-SECRET', DEFAULT_API_SECRET)
    
    if not api_key or not api_secret:
        return jsonify({'error': '請提供 API Key 或設定環境變數'}), 400
    
    try:
        timestamp = int(time.time() * 1000)
        query = f'timestamp={timestamp}'
        signature = sign(query, api_secret)
        
        url = f"{BINANCE_API}/api/v3/account?{query}&signature={signature}"
        headers = {'X-MBX-APIKEY': api_key}
        
        resp = requests.get(url, headers=headers, timeout=10)
        
        if resp.status_code != 200:
            return jsonify({'error': f'API錯誤: {resp.status_code}', 'detail': resp.text}), resp.status_code
        
        data = resp.json()
        
        # 過濾有餘額的幣種
        balances = []
        for b in data.get('balances', []):
            free = float(b.get('free', 0))
            locked = float(b.get('locked', 0))
            if free > 0 or locked > 0:
                balances.append({
                    'asset': b['asset'],
                    'free': free,
                    'locked': locked,
                    'total': free + locked
                })
        
        return jsonify({
            'balances': balances,
            'canTrade': data.get('canTrade'),
            'canWithdraw': data.get('canWithdraw'),
            'canDeposit': data.get('canDeposit')
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/prices', methods=['GET'])
def get_prices():
    """取得幣種價格"""
    try:
        resp = requests.get(f"{BINANCE_API}/api/v3/ticker/price", timeout=10)
        prices = {}
        for p in resp.json():
            prices[p['symbol']] = float(p['price'])
        return jsonify(prices)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/balance', methods=['GET'])
def get_balance():
    """計算 USDT 總價值"""
    api_key = request.headers.get('X-API-KEY', '')
    api_secret = request.headers.get('X-API-SECRET', '')
    
    if not api_key or not api_secret:
        return jsonify({'error': '請提供 API Key 和 Secret'}), 400
    
    try:
        # 取得帳戶餘額
        timestamp = int(time.time() * 1000)
        query = f'timestamp={timestamp}'
        signature = sign(query, api_secret)
        
        url = f"{BINANCE_API}/api/v3/account?{query}&signature={signature}"
        headers = {'X-MBX-APIKEY': api_key}
        
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code != 200:
            return jsonify({'error': f'API錯誤: {resp.status_code}'}), resp.status_code
        
        data = resp.json()
        
        # 取得價格
        prices_resp = requests.get(f"{BINANCE_API}/api/v3/ticker/price", timeout=10)
        prices = {}
        for p in prices_resp.json():
            prices[p['symbol']] = float(p['price'])
        
        # 計算總價值
        total_usdt = 0
        holdings = []
        
        for b in data.get('balances', []):
            free = float(b.get('free', 0))
            locked = float(b.get('locked', 0))
            total = free + locked
            
            if total > 0:
                asset = b['asset']
                price = prices.get(asset + 'USDT', 0)
                
                if asset == 'USDT':
                    value = total
                elif price > 0:
                    value = total * price
                else:
                    value = 0
                
                if value > 1:  # 只顯示價值 > 1 USDT
                    total_usdt += value
                    holdings.append({
                        'asset': asset,
                        'amount': total,
                        'price': price,
                        'value': value
                    })
        
        # 按價值排序
        holdings.sort(key=lambda x: x['value'], reverse=True)
        
        return jsonify({
            'totalUSDT': total_usdt,
            'holdings': holdings
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def calculate_rsi(prices, period=14):
    """計算 RSI（相對強弱指數）"""
    if len(prices) < period + 1:
        return 50
    
    deltas = []
    for i in range(1, len(prices)):
        deltas.append(prices[i] - prices[i-1])
    
    gains = [d if d > 0 else 0 for d in deltas]
    losses = [-d if d < 0 else 0 for d in deltas]
    
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    if avg_loss == 0:
        return 100
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return round(rsi, 2)

def calculate_macd(prices, fast=12, slow=26, signal=9):
    """計算 MACD"""
    if len(prices) < slow + signal:
        return "neutral", 0, 0, 0
    
    # 計算 EMA
    def calc_ema(data, period):
        ema = []
        multiplier = 2 / (period + 1)
        ema.append(data[0])
        for i in range(1, len(data)):
            ema.append((data[i] - ema[-1]) * multiplier + ema[-1])
        return ema
    
    ema_fast = calc_ema(prices, fast)
    ema_slow = calc_ema(prices, slow)
    
    macd_line = []
    for i in range(len(ema_fast)):
        if i < len(ema_slow):
            macd_line.append(ema_fast[i] - ema_slow[i])
    
    # Signal line (EMA of MACD)
    if len(macd_line) < signal:
        return "neutral", 0, 0, 0
    
    signal_line = calc_ema(macd_line[-signal-10:], signal) if len(macd_line) > signal else macd_line
    
    if len(macd_line) < 1 or len(signal_line) < 1:
        return "neutral", 0, 0, 0
    
    macd_value = macd_line[-1]
    signal_value = signal_line[-1]
    
    if macd_value > signal_value:
        trend = "bullish"
    elif macd_value < signal_value:
        trend = "bearish"
    else:
        trend = "neutral"
    
    return trend, round(macd_value, 2), round(signal_value, 2), macd_line

def calculate_trend(prices):
    """計算簡單價格趨勢"""
    if len(prices) < 2:
        return "neutral"
    
    # 使用最近 20 根K線判斷趨勢
    recent = prices[-20:] if len(prices) >= 20 else prices
    
    first_price = recent[0]
    last_price = recent[-1]
    change_pct = ((last_price - first_price) / first_price) * 100
    
    if change_pct > 2:
        return "上漲"
    elif change_pct < -2:
        return "下跌"
    else:
        return "震盪"

def get_fear_greed_index():
    """嘗試獲取恐懼貪婪指數（使用模擬值）"""
    # 嘗試從 coingecko 獲取比特幣主導率作為參考
    try:
        resp = requests.get("https://api.coingecko.com/api/v3/global", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            btc_dominance = data.get('data', {}).get('market_cap_percentage', {}).get('btc', 50)
            # 簡單映射：BTC 主導率 50%=中性, >55%=恐懼, <45%=貪婪
            if btc_dominance > 55:
                return int(30 + (60 - btc_dominance))
            elif btc_dominance < 45:
                return int(70 + (45 - btc_dominance))
    except:
        pass
    
    # 使用時間作為 seed 生成穩定的模擬值
    import datetime
    now = datetime.datetime.now()
    hour = now.hour
    # 簡單週期性模擬：白天較貪婪，晚間較恐懼
    base = 50 + 15 * ((hour - 12) / 12)
    return int(base)

@app.route('/api/technical-analysis', methods=['GET'])
def technical_analysis():
    """技術指標分析"""
    symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT']
    result = {
        'fearGreedIndex': get_fear_greed_index(),
        'coins': []
    }
    
    try:
        # 一次獲取所有幣的 24hr 價格變化
        ticker_resp = requests.get(f"{BINANCE_API}/api/v3/ticker/24hr", timeout=10)
        ticker_data = {t['symbol']: t for t in ticker_resp.json()}
        
        for symbol in symbols:
            try:
                # 獲取 K線數據（1小時，100根）
                klines_resp = requests.get(
                    f"{BINANCE_API}/api/v3/klines",
                    params={
                        'symbol': symbol,
                        'interval': '1h',
                        'limit': 100
                    },
                    timeout=10
                )
                klines = klines_resp.json()
                
                if not klines:
                    continue
                
                # 提取收盤價
                close_prices = [float(k[4]) for k in klines]
                current_price = close_prices[-1]
                
                # 計算技術指標
                rsi = calculate_rsi(close_prices, 14)
                macd_trend, macd_val, signal_val, _ = calculate_macd(close_prices)
                trend = calculate_trend(close_prices)
                
                # 取得 24hr 變化
                ticker = ticker_data.get(symbol, {})
                change_24h = float(ticker.get('priceChangePercent', 0))
                
                # 產生交易信號
                if rsi < 35 and macd_trend == "bullish":
                    signal = "買入"
                elif rsi > 65 or macd_trend == "bearish":
                    signal = "賣出"
                else:
                    signal = "觀望"
                
                result['coins'].append({
                    'symbol': symbol,
                    'price': round(current_price, 2),
                    'change': round(change_24h, 2),
                    'rsi': rsi,
                    'macd': macd_trend,
                    'signal': signal
                })
                
            except Exception as e:
                print(f"Error processing {symbol}: {e}")
                continue
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("🚀 幣安後端啟動中...")
    print("📍 http://localhost:5000")
    print("📊 技術分析: http://localhost:5000/api/technical-analysis")
    app.run(port=5001, debug=True)
